import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Download, i as FileUp, n as Shield, o as CircleCheck, r as Flame, t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CFR3M2Ui.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Byte patch for Dark Souls II: Scholar of the First Sin (2015 Steam PE). */
var SOTFS_2015_TIMESTAMP = 1429527574;
/** mov [rcx+4], 1/60; mov [rcx+8], 1/60; mov [rcx+0xC], 59.999996 */
var LIMITER_PREFIX = new Uint8Array([
	199,
	65,
	4,
	137,
	136,
	136,
	60,
	199,
	65,
	8,
	137,
	136,
	136,
	60,
	199,
	65,
	12,
	255,
	255,
	111,
	66
]);
function u32(bytes, off) {
	return (bytes[off] | bytes[off + 1] << 8 | bytes[off + 2] << 16 | bytes[off + 3] << 24) >>> 0;
}
function f32le(bytes, off) {
	return new DataView(bytes.buffer, bytes.byteOffset + off, 4).getFloat32(0, true);
}
function setF32le(bytes, off, value) {
	new DataView(bytes.buffer, bytes.byteOffset + off, 4).setFloat32(0, value, true);
}
function findBytes(hay, needle, from = 0) {
	outer: for (let i = from; i <= hay.length - needle.length; i++) {
		for (let j = 0; j < needle.length; j++) if (hay[i + j] !== needle[j]) continue outer;
		return i;
	}
	return -1;
}
function findLimiterTriplet(bytes) {
	const stock = findBytes(bytes, LIMITER_PREFIX);
	if (stock >= 0) return stock;
	for (let i = 0; i < bytes.length - 21; i++) if (bytes[i] === 199 && bytes[i + 1] === 65 && bytes[i + 2] === 4 && bytes[i + 7] === 199 && bytes[i + 8] === 65 && bytes[i + 9] === 8 && bytes[i + 14] === 199 && bytes[i + 15] === 65 && bytes[i + 16] === 12) {
		const cap = f32le(bytes, i + 17);
		if (cap > 30 && cap < 4e3) return i;
	}
	return -1;
}
function scanExe(bytes) {
	const size = bytes.length;
	const empty = (status) => ({
		status,
		timestamp: null,
		timestampUtc: null,
		timestampMatch: false,
		size,
		limiterOffset: null,
		currentCap: null,
		machine: null
	});
	if (size < 512 || bytes[0] !== 77 || bytes[1] !== 90) return empty("not-pe");
	const eLfanew = u32(bytes, 60);
	if (eLfanew + 24 >= size) return empty("not-pe");
	if (bytes[eLfanew] !== 80 || bytes[eLfanew + 1] !== 69) return empty("not-pe");
	const coff = eLfanew + 4;
	const machine = bytes[coff] | bytes[coff + 1] << 8;
	const timestamp = u32(bytes, coff + 4);
	const timestampUtc = (/* @__PURE__ */ new Date(timestamp * 1e3)).toISOString();
	const magicOff = coff + 20;
	const magic = bytes[magicOff] | bytes[magicOff + 1] << 8;
	const timestampMatch = timestamp === SOTFS_2015_TIMESTAMP;
	if (machine !== 34404 || magic !== 523) return {
		...empty("not-64"),
		timestamp,
		timestampUtc,
		timestampMatch,
		machine
	};
	const limiterOffset = findLimiterTriplet(bytes);
	if (limiterOffset < 0) return {
		status: timestampMatch ? "limiter-missing" : "wrong-game",
		timestamp,
		timestampUtc,
		timestampMatch,
		size,
		limiterOffset: null,
		currentCap: null,
		machine
	};
	const currentCap = f32le(bytes, limiterOffset + 17);
	return {
		status: findBytes(bytes, LIMITER_PREFIX) === limiterOffset ? "ok" : "already-patched",
		timestamp,
		timestampUtc,
		timestampMatch,
		size,
		limiterOffset,
		currentCap,
		machine
	};
}
function applyFpsPatch(source, fps) {
	if (fps < 61 || fps > 1e3) throw new Error("FPS must be between 61 and 1000.");
	const scan = scanExe(source);
	if (scan.limiterOffset == null) throw new Error("Could not find the 60 FPS limiter in this executable.");
	const out = new Uint8Array(source);
	const dt = 1 / fps;
	const off = scan.limiterOffset;
	setF32le(out, off + 3, dt);
	setF32le(out, off + 10, dt);
	setF32le(out, off + 17, fps);
	return out;
}
function describeScan(scan) {
	switch (scan.status) {
		case "ok": return "Stock Scholar limiter found. Ready to patch.";
		case "already-patched": return `Limiter already edited (cap ≈ ${scan.currentCap?.toFixed(0)} FPS). You can re-patch.`;
		case "not-pe": return "This is not a Windows PE executable.";
		case "not-64": return "This is not a 64-bit Scholar of the First Sin executable (vanilla DS2 is 32-bit).";
		case "wrong-game": return "This executable is not the 2015 SotFS build this patch was made for.";
		case "limiter-missing": return "Looks like SotFS, but the 60 FPS limiter signature was not found.";
		default: return "Unknown scan result.";
	}
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var PRESETS = [
	120,
	144,
	165,
	240
];
function Home() {
	const inputRef = (0, import_react.useRef)(null);
	const [fileName, setFileName] = (0, import_react.useState)(null);
	const [bytes, setBytes] = (0, import_react.useState)(null);
	const [scan, setScan] = (0, import_react.useState)(null);
	const [fps, setFps] = (0, import_react.useState)(120);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [doneName, setDoneName] = (0, import_react.useState)(null);
	const canPatch = scan && (scan.status === "ok" || scan.status === "already-patched");
	const onFile = (0, import_react.useCallback)(async (file) => {
		setError(null);
		setDoneName(null);
		setBusy(true);
		setFileName(file.name);
		try {
			const buf = new Uint8Array(await file.arrayBuffer());
			const result = scanExe(buf);
			setBytes(buf);
			setScan(result);
		} catch (e) {
			setError(e instanceof Error ? e.message : "Failed to read file.");
			setBytes(null);
			setScan(null);
		} finally {
			setBusy(false);
		}
	}, []);
	const onDrop = (0, import_react.useCallback)((ev) => {
		ev.preventDefault();
		const f = ev.dataTransfer.files[0];
		if (f) onFile(f);
	}, [onFile]);
	const patchAndDownload = (0, import_react.useCallback)(() => {
		if (!bytes || !canPatch) return;
		setError(null);
		try {
			const patched = applyFpsPatch(bytes, fps);
			const copy = new Uint8Array(patched.byteLength);
			copy.set(patched);
			const blob = new Blob([copy], { type: "application/vnd.microsoft.portable-executable" });
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			const outName = `${(fileName ?? "DarkSoulsII.exe").replace(/\.exe$/i, "")}.fps${fps}.exe`;
			a.href = url;
			a.download = outName;
			a.click();
			URL.revokeObjectURL(url);
			setDoneName(outName);
		} catch (e) {
			setError(e instanceof Error ? e.message : "Patch failed.");
		}
	}, [
		bytes,
		canPatch,
		fileName,
		fps
	]);
	const statusTone = (0, import_react.useMemo)(() => {
		if (!scan) return "muted";
		if (scan.status === "ok") return "ok";
		if (scan.status === "already-patched") return "gold";
		return "danger";
	}, [scan]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh overflow-x-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute inset-0 opacity-40",
				style: { background: "radial-gradient(ellipse 80% 50% at 50% -10%, color-mix(in srgb, var(--color-ember) 28%, transparent), transparent 70%)" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "relative border-b border-border px-4 py-6 sm:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, {
						className: "mt-1 size-7 shrink-0 text-ember",
						strokeWidth: 1.75
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xs tracking-[0.28em] text-gold uppercase",
							children: "Scholar of the First Sin · 2015 build"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-bold tracking-wide text-fg sm:text-4xl",
							children: "Frameforge"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 max-w-xl text-sm text-muted",
							children: [
								"Unlocks the 60 FPS software cap inside ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-fg",
									children: "DarkSoulsII.exe"
								}),
								". Your file never leaves this browser. We do not host or ship FromSoftware's executable."
							]
						})
					] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative mx-auto flex max-w-3xl flex-col gap-8 px-4 py-8 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						onDragOver: (e) => e.preventDefault(),
						onDrop,
						className: "rounded-radius border border-border bg-surface p-5 sm:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg text-gold",
								children: "1. Drop your executable"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									"Use the copy next to ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
										className: "text-fg",
										children: "DarkSoulsII.exe"
									}),
									" in the SotFS",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
										className: "text-fg",
										children: "Game"
									}),
									" folder. Backup first. Steam verify will restore the original."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: inputRef,
								type: "file",
								accept: ".exe,application/x-msdownload,application/octet-stream",
								className: "sr-only",
								onChange: (e) => {
									const f = e.target.files?.[0];
									if (f) onFile(f);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => inputRef.current?.click(),
								className: "mt-5 flex min-h-12 w-full items-center justify-center gap-2 rounded-radius border border-dashed border-gold/50 bg-raised px-4 py-4 text-sm text-fg transition-colors hover:border-gold hover:bg-raised/80",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, { className: "size-4 text-gold" }), busy ? "Reading…" : fileName ? fileName : "Choose DarkSoulsII.exe or drop it here"]
							}),
							scan && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("mt-4 flex gap-3 rounded-radius border px-3 py-3 text-sm", statusTone === "ok" && "border-ok/40 bg-ok/10 text-fg", statusTone === "gold" && "border-gold/40 bg-gold/10 text-fg", statusTone === "danger" && "border-danger/40 bg-danger/10 text-fg"),
								children: [statusTone === "danger" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 size-4 shrink-0 text-danger" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-0.5 size-4 shrink-0 text-ok" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: describeScan(scan) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 font-mono text-xs text-muted",
										children: [
											scan.size.toLocaleString(),
											" bytes",
											scan.timestampUtc ? ` · PE time ${scan.timestampUtc.slice(0, 10)}` : "",
											scan.currentCap != null ? ` · cap ${scan.currentCap.toFixed(1)} FPS` : "",
											scan.limiterOffset != null ? ` · limiter @ 0x${scan.limiterOffset.toString(16)}` : ""
										]
									}),
									!scan.timestampMatch && scan.limiterOffset != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs text-gold",
										children: "Timestamp is not the April 2015 SotFS build we reverse-engineered. The limiter signature still matched — patch at your own risk."
									})
								] })]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-radius border border-border bg-surface p-5 sm:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg text-gold",
								children: "2. Choose a cap"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "120 is the safest. Higher than 144 can still desync cloth, jumps, and durability even with the limiter raised. Cap in RTSS / driver if your display is 240+."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 flex flex-wrap gap-2",
								children: PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setFps(p),
									className: cn("min-h-11 min-w-16 rounded-radius border px-4 text-sm", fps === p ? "border-ember bg-ember text-fg" : "border-border bg-raised text-muted hover:text-fg"),
									children: p
								}, p))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-5 block text-sm text-muted",
								children: ["Custom FPS", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 61,
									max: 1e3,
									value: fps,
									onChange: (e) => setFps(Number(e.target.value) || 120),
									className: "mt-1 min-h-11 w-full rounded-radius border border-border bg-raised px-3 text-fg outline-none focus:border-gold"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: !canPatch,
								onClick: patchAndDownload,
								className: "mt-5 flex min-h-12 w-full items-center justify-center gap-2 rounded-radius bg-ember px-4 text-sm font-semibold text-fg disabled:cursor-not-allowed disabled:opacity-40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download patched EXE"]
							}),
							doneName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-sm text-ok",
								children: [
									"Saved as ",
									doneName,
									". Rename it to DarkSoulsII.exe in the Game folder (keep a backup of the original)."
								]
							}),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-danger",
								children: error
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-radius border border-border bg-surface p-5 sm:p-7",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display flex items-center gap-2 text-lg text-gold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4" }), "What this does — and what it does not"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-3 list-disc space-y-2 pl-5 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									"Your exe is the ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "font-semibold text-fg",
										children: "2015 SotFS"
									}),
									" build (PE timestamp 2015-04-20). Emoose's DS2FrameUnlimiter targets the 2022 Steam update and will refuse this file."
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "This writes the in-engine frame-wait struct: min delta 1/60 and max FPS ~60 become 1/your-cap and your cap. It does not inject a DLL." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									"Gameplay speed, durability, jump height, and cloth were authored at 60 Hz. Raising FPS without emoose-style physics hooks can still speed things up. Prefer 120 and play",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "font-semibold text-fg",
										children: "offline"
									}),
									"."
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Vanilla Dark Souls 2 (32-bit) is a different exe. This patch will reject it." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do not share the patched exe. Patch your own Steam copy." })
							]
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Home as component };

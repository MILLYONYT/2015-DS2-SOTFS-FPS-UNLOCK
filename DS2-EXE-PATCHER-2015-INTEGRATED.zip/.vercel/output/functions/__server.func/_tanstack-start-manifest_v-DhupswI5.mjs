//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DhupswI5.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BmAKdX6l.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BmAKdX6l.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DRoAWs74.js"]
	}
} });
//#endregion
export { tsrStartManifest };

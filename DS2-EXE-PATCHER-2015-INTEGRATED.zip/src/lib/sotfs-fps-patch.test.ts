import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { describe, it } from "node:test";
import { applyFpsPatch, LIMITER_PREFIX, scanExe } from "./sotfs-fps-patch.ts";

describe("sotfs fps patch", () => {
  it("finds and retargets the 2015 limiter", () => {
    const buf = new Uint8Array(readFileSync("/workspace/attachments/DarkSoulsII.exe"));
    const scan = scanExe(buf);
    assert.equal(scan.status, "ok");
    assert.ok(scan.limiterOffset != null);
    assert.ok(Math.abs((scan.currentCap ?? 0) - 60) < 0.01);
    const patched = applyFpsPatch(buf, 120);
    const again = scanExe(patched);
    assert.equal(again.status, "already-patched");
    assert.ok(Math.abs((again.currentCap ?? 0) - 120) < 0.05);
    assert.equal(patched.length, buf.length);
    let origHits = 0;
    const n = LIMITER_PREFIX;
    for (let i = 0; i <= patched.length - n.length; i++) {
      let ok = true;
      for (let j = 0; j < n.length; j++) if (patched[i + j] !== n[j]) { ok = false; break; }
      if (ok) origHits++;
    }
    assert.equal(origHits, 0);
  });
});

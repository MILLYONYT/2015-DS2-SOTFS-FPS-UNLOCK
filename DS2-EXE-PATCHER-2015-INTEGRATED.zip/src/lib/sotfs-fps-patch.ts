/** Byte patch for the 2015 Scholar of the First Sin PE executable. */
export const SOTFS_2015_TIMESTAMP = 1429527574;

export const LIMITER_PREFIX = new Uint8Array([
  0xc7, 0x41, 0x04, 0x89, 0x88, 0x88, 0x3c,
  0xc7, 0x41, 0x08, 0x89, 0x88, 0x88, 0x3c,
  0xc7, 0x41, 0x0c, 0xff, 0xff, 0x6f, 0x42,
]);

function findBytes(hay: Uint8Array, needle: Uint8Array): number {
  outer: for (let i = 0; i <= hay.length - needle.length; i++) {
    for (let j = 0; j < needle.length; j++) {
      if (hay[i + j] !== needle[j]) continue outer;
    }
    return i;
  }
  return -1;
}

function setF32le(bytes: Uint8Array, off: number, value: number) {
  new DataView(bytes.buffer, bytes.byteOffset + off, 4).setFloat32(0, value, true);
}

export function applyFpsPatch(source: Uint8Array, fps: number): Uint8Array {
  if (fps < 61 || fps > 1000) throw new Error("FPS must be between 61 and 1000.");
  const off = findBytes(source, LIMITER_PREFIX);
  if (off < 0) throw new Error("2015 FPS limiter signature not found.");
  const out = new Uint8Array(source);
  setF32le(out, off + 17, fps);
  return out;
}

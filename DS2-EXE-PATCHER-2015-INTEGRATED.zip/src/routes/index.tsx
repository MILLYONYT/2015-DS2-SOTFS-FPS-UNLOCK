import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useMemo, useRef, useState } from "react";
import { AlertTriangle, CheckCircle2, Download, FileUp, Flame, Shield } from "lucide-react";
import {
  applyFpsPatch,
  describeScan,
  scanExe,
  type ExeScan,
} from "@/lib/sotfs-fps-patch";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

const PRESETS = [120, 144, 165, 240] as const;

function Home() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [bytes, setBytes] = useState<Uint8Array | null>(null);
  const [scan, setScan] = useState<ExeScan | null>(null);
  const [fps, setFps] = useState(120);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [doneName, setDoneName] = useState<string | null>(null);

  const canPatch = scan && (scan.status === "ok" || scan.status === "already-patched");

  const onFile = useCallback(async (file: File) => {
    setError(null);
    setDoneName(null);
    setBusy(true);
    setFileName(file.name);
    try {
      const buf = new Uint8Array(await file.arrayBuffer());
      const result = scanExe(buf);
      setBytes(buf);
      setScan(result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to read file.");
      setBytes(null);
      setScan(null);
    } finally {
      setBusy(false);
    }
  }, []);

  const onDrop = useCallback(
    (ev: React.DragEvent) => {
      ev.preventDefault();
      const f = ev.dataTransfer.files[0];
      if (f) void onFile(f);
    },
    [onFile],
  );

  const patchAndDownload = useCallback(() => {
    if (!bytes || !canPatch) return;
    setError(null);
    try {
      const patched = applyFpsPatch(bytes, fps);
      const copy = new Uint8Array(patched.byteLength);
      copy.set(patched);
      const blob = new Blob([copy], { type: "application/vnd.microsoft.portable-executable" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      const base = (fileName ?? "DarkSoulsII.exe").replace(/\.exe$/i, "");
      const outName = `${base}.fps${fps}.exe`;
      a.href = url;
      a.download = outName;
      a.click();
      URL.revokeObjectURL(url);
      setDoneName(outName);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Patch failed.");
    }
  }, [bytes, canPatch, fileName, fps]);

  const statusTone = useMemo(() => {
    if (!scan) return "muted";
    if (scan.status === "ok") return "ok";
    if (scan.status === "already-patched") return "gold";
    return "danger";
  }, [scan]);

  return (
    <div className="relative min-h-dvh overflow-x-hidden">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{
          background:
            "radial-gradient(ellipse 80% 50% at 50% -10%, color-mix(in srgb, var(--color-ember) 28%, transparent), transparent 70%)",
        }}
      />
      <header className="relative border-b border-border px-4 py-6 sm:px-8">
        <div className="mx-auto flex max-w-3xl items-start gap-3">
          <Flame className="mt-1 size-7 shrink-0 text-ember" strokeWidth={1.75} />
          <div>
            <p className="font-display text-xs tracking-[0.28em] text-gold uppercase">
              Scholar of the First Sin · 2015 build
            </p>
            <h1 className="font-display text-3xl font-bold tracking-wide text-fg sm:text-4xl">
              Frameforge
            </h1>
            <p className="mt-2 max-w-xl text-sm text-muted">
              Unlocks the 60 FPS software cap inside <span className="text-fg">DarkSoulsII.exe</span>.
              Your file never leaves this browser. We do not host or ship FromSoftware's
              executable.
            </p>
          </div>
        </div>
      </header>

      <main className="relative mx-auto flex max-w-3xl flex-col gap-8 px-4 py-8 sm:px-8">
        <section
          onDragOver={(e) => e.preventDefault()}
          onDrop={onDrop}
          className="rounded-radius border border-border bg-surface p-5 sm:p-7"
        >
          <h2 className="font-display text-lg text-gold">1. Drop your executable</h2>
          <p className="mt-1 text-sm text-muted">
            Use the copy next to <code className="text-fg">DarkSoulsII.exe</code> in the SotFS{" "}
            <code className="text-fg">Game</code> folder. Backup first. Steam verify will restore
            the original.
          </p>
          <input
            ref={inputRef}
            type="file"
            accept=".exe,application/x-msdownload,application/octet-stream"
            className="sr-only"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void onFile(f);
            }}
          />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="mt-5 flex min-h-12 w-full items-center justify-center gap-2 rounded-radius border border-dashed border-gold/50 bg-raised px-4 py-4 text-sm text-fg transition-colors hover:border-gold hover:bg-raised/80"
          >
            <FileUp className="size-4 text-gold" />
            {busy ? "Reading…" : fileName ? fileName : "Choose DarkSoulsII.exe or drop it here"}
          </button>

          {scan && (
            <div
              className={cn(
                "mt-4 flex gap-3 rounded-radius border px-3 py-3 text-sm",
                statusTone === "ok" && "border-ok/40 bg-ok/10 text-fg",
                statusTone === "gold" && "border-gold/40 bg-gold/10 text-fg",
                statusTone === "danger" && "border-danger/40 bg-danger/10 text-fg",
              )}
            >
              {statusTone === "danger" ? (
                <AlertTriangle className="mt-0.5 size-4 shrink-0 text-danger" />
              ) : (
                <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-ok" />
              )}
              <div>
                <p>{describeScan(scan)}</p>
                <p className="mt-1 font-mono text-xs text-muted">
                  {scan.size.toLocaleString()} bytes
                  {scan.timestampUtc ? ` · PE time ${scan.timestampUtc.slice(0, 10)}` : ""}
                  {scan.currentCap != null ? ` · cap ${scan.currentCap.toFixed(1)} FPS` : ""}
                  {scan.limiterOffset != null
                    ? ` · limiter @ 0x${scan.limiterOffset.toString(16)}`
                    : ""}
                </p>
                {!scan.timestampMatch && scan.limiterOffset != null && (
                  <p className="mt-2 text-xs text-gold">
                    Timestamp is not the April 2015 SotFS build we reverse-engineered. The limiter
                    signature still matched — patch at your own risk.
                  </p>
                )}
              </div>
            </div>
          )}
        </section>

        <section className="rounded-radius border border-border bg-surface p-5 sm:p-7">
          <h2 className="font-display text-lg text-gold">2. Choose a cap</h2>
          <p className="mt-1 text-sm text-muted">
            120 is the safest. Higher than 144 can still desync cloth, jumps, and durability even
            with the limiter raised. Cap in RTSS / driver if your display is 240+.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {PRESETS.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setFps(p)}
                className={cn(
                  "min-h-11 min-w-16 rounded-radius border px-4 text-sm",
                  fps === p
                    ? "border-ember bg-ember text-fg"
                    : "border-border bg-raised text-muted hover:text-fg",
                )}
              >
                {p}
              </button>
            ))}
          </div>
          <label className="mt-5 block text-sm text-muted">
            Custom FPS
            <input
              type="number"
              min={61}
              max={1000}
              value={fps}
              onChange={(e) => setFps(Number(e.target.value) || 120)}
              className="mt-1 min-h-11 w-full rounded-radius border border-border bg-raised px-3 text-fg outline-none focus:border-gold"
            />
          </label>
          <button
            type="button"
            disabled={!canPatch}
            onClick={patchAndDownload}
            className="mt-5 flex min-h-12 w-full items-center justify-center gap-2 rounded-radius bg-ember px-4 text-sm font-semibold text-fg disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Download className="size-4" />
            Download patched EXE
          </button>
          {doneName && (
            <p className="mt-3 text-sm text-ok">
              Saved as {doneName}. Rename it to DarkSoulsII.exe in the Game folder (keep a backup of
              the original).
            </p>
          )}
          {error && <p className="mt-3 text-sm text-danger">{error}</p>}
        </section>

        <section className="rounded-radius border border-border bg-surface p-5 sm:p-7">
          <h2 className="font-display flex items-center gap-2 text-lg text-gold">
            <Shield className="size-4" />
            What this does — and what it does not
          </h2>
          <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-muted">
            <li>
              Your exe is the <strong className="font-semibold text-fg">2015 SotFS</strong> build
              (PE timestamp 2015-04-20). Emoose's DS2FrameUnlimiter targets the 2022 Steam
              update and will refuse this file.
            </li>
            <li>
              This writes the in-engine frame-wait struct: min delta 1/60 and max FPS ~60 become
              1/your-cap and your cap. It does not inject a DLL.
            </li>
            <li>
              Gameplay speed, durability, jump height, and cloth were authored at 60 Hz. Raising
              FPS without emoose-style physics hooks can still speed things up. Prefer 120 and play{" "}
              <strong className="font-semibold text-fg">offline</strong>.
            </li>
            <li>Vanilla Dark Souls 2 (32-bit) is a different exe. This patch will reject it.</li>
            <li>Do not share the patched exe. Patch your own Steam copy.</li>
          </ul>
        </section>
      </main>
    </div>
  );
}
